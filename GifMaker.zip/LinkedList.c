#include "Linkedlist.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/**
 * @brief Creates and initializes a Frame structure.
 *
 * @param name Frame name string
 * @param duration Frame duration in ms
 * @param path Frame path
 * @return Pointer to a frame or NULL if allocation fails.
 */
Frame *buildFrame(char *name, unsigned int duration, char *path)
{
    Frame *newFrame = (Frame *)malloc(sizeof(Frame));
    if (!newFrame)
    {
        return NULL;
    }
    
    newFrame->name = NULL;
    newFrame->path = NULL;
    newFrame->duration = duration;

    if (name)
    {
        newFrame->name = name;
    }

    if (path)
    {
        newFrame->path = path;
    }

    return newFrame;
}

/**
 * @brief Allocates memory and creates a new frame node. 
 *  
 * @param dataFrame pointer to a frame
 * @return Pointer to a frame node or NULL if allocation fails.
 */
FrameNode *createNode(Frame *dataFrame)
{
    FrameNode *newNode = (FrameNode *)malloc(sizeof(FrameNode));
    if (!newNode)
    {
        return NULL;
    }
    
    newNode->frame = dataFrame;
    newNode->next = NULL;

    return newNode;
}

/**
 * @brief Returns last node of a list 
 *  
 * @param head pointer to the head of a list
 * @return Pointer to a frame node or NULL if list is empty fails.
 */
FrameNode *findLast(FrameNode *head)
{
    if (head == NULL)
    {
        return NULL;
    }

    while (head->next)
    {
        head = head->next;
    }

    return head;
}

/**
 * @brief attach a node to the last node of your list  
 * 
 * @param head pointer to the pointer that holds the first node 
 * @param last pointer to the pointer that holds the last node
 * @param newNode node to attach
 *
 * @return None
 */
void attachNode(FrameNode **head, FrameNode **last, FrameNode *newNode)
{
    if (!newNode)
    {
        return;
    }

    if (!*head)
    {
        *head = newNode;
        *last = newNode;
    }
    else {
        newNode->next = NULL;
        (*last)->next = newNode;
        *last = newNode;
    }   
}


/**
 * @brief search for a node by name 
 * 
 * @param head pointer to the pointer that holds the first node 
 * @param name string that holds name
 *
 * @return framenode if found else NULL
 */
FrameNode *searchNode(FrameNode *head, const char *name)
{
    while (head)
    {
        if (strcmp(head->frame->name, name) == 0)
            return head;

        head = head->next;
    }
    
    return NULL;
}


/**
 * @brief remove a node from the list  
 * 
 * @param head pointer to the pointer that holds the first node 
 * @param name string that holds name
 *
 * @return bool found the node or not
 */
bool removeFrame(FrameNode **head, FrameNode **last, const char *name)
{
    FrameNode *curr = *head;
    FrameNode *prev = NULL;

    while (curr)
    {
        if (strcmp(curr->frame->name, name) == 0)
        {
            if (!prev)
            {
                *head = curr->next;
            }
            else {
                prev->next = curr->next;
            }
            if (curr == *last)
            {
                *last = prev;
            }
            freeNode(curr);
            return true;
        }
        prev = curr;
        curr = curr->next;
    }
    return false;
}



/**
 * @brief edit duration of one node
 * 
 * @param head pointer to the first node 
 * @param name a name string 
 * @param duration new duration 
 *
 * @return bool found the node or not
 */
bool editOneDuration(FrameNode *head, const char *name, int duration)
{
    FrameNode *node = searchNode(head, name);
    if (!node)
    {
        return false;
    }
    node->frame->duration = duration;

    return true;
}


/**
 * @brief edit duration of all nodes
 * 
 * @param head pointer to the first node 
 * @param duration new duration 
 *
 * @return None
 */
void editAllDuration(FrameNode *head, int newDuration)
{ 
    while(head)
    {
        head->frame->duration = newDuration;

        head = head->next;
    }
}


/**
 * @brief Function switches two frames 
 * 
 * @param firstFrame pointer to the first node 
 * @param firstFrame pointer to the second node 
 *
 * @return None
 */
void switchFrames(FrameNode *firstFrame, FrameNode *secondFrame)
{
    Frame *temp = firstFrame->frame;
    firstFrame->frame = secondFrame->frame;
    secondFrame->frame = temp;
}

void listFrames(FrameNode *head)
{        
    printf("\t\tName\t\tDuration\t\tPath\n");

    while (head)
    {
        Frame *frame = head->frame;
        printf("\t\t%s\t\t%d\t\t%s\n", frame->name, frame->duration, frame->path);

        head = head->next;
    }
}


/**
 * @brief frees a node from your list  
 * 
 * @param node pointed to the node you want to free 
 *
 * @return None
 */
void freeNode(FrameNode *node)
{
    if (!node)
    {
        return;
    }

    free(node->frame->name);
    free(node->frame->path);

    free(node->frame);
    free(node);
}

void freeList(FrameNode *head)
{
    while (head)
    {
        FrameNode *next = head->next;
        freeNode(head);
        head = next;
    }
}

