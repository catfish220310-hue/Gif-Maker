##### README

##### 

##### This project is a movie maker written in C. The user can create a movie from image frames, edit the frames, save and load projects, and play the movie using Raylib.

##### 

##### Files:

##### 

### interaction.c

##### Contains functions that interact with the user.

##### Functions:

##### 

##### \* displayStartupMenu() - shows the startup menu.

##### \* printMainMenu() - shows the main menu.

##### \* getChoice() - gets the user's menu choice.

##### \* getString() - reads a string from the user.

##### \* getDuration() - reads a duration value from the user.

##### 

### LinkedList.c

##### Contains all linked list and frame management functions.

##### Functions:

##### 

##### \* buildFrame() - creates a frame.

##### \* createNode() - creates a linked list node.

##### \* findLast() - finds the last node in the list.

##### \* attachNode() - adds a node to the end of the list.

##### \* searchNode() - searches for a frame by name.

##### \* removeFrame() - removes a frame from the list.

##### \* editOneDuration() - changes the duration of one frame.

##### \* editAllDuration() - changes the duration of all frames.

##### \* switchFrames() - swaps two frames.

##### \* listFrames() - prints all frames.

##### \* freeNode() - frees a single node.

##### \* freeList() - frees the entire list.

### 

### view.c

##### Contains the movie playback function.

##### Functions:

##### 

* ##### play() - displays all frames one after another according to their duration.

##### 



### projects.c

##### contains the movie loading and saving projects functions

* ##### saveProject - saves a project in a file of your choice works for text files.
* ##### loadProject - loads a project file works only for txt filess



##### Data Structures:

##### 

##### Frame

##### Stores:

##### 

##### \* frame name

##### \* frame path

##### \* frame duration

##### 

##### FrameNode

##### Stores:

##### 

##### \* pointer to a Frame

##### \* pointer to the next node

##### 

##### Memory Management:

##### The project uses dynamic memory allocation. All allocated memory is released using freeNode() and freeList() before the program exits.

##### 

##### Libraries:

##### 

##### \* Standard C libraries

##### \* Raylib (used for displaying images and playing the movie)

##### 

