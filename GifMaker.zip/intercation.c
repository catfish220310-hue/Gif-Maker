#include "interaction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 4096

/**
 * @brief Displays the startup menu.
 *
 * Shows the options to create a new project or load an existing one.
 */
void displayStartupMenu()
{
    printf("Welcome to Magshimim Movie Maker! What would you like to do?\n");
    printf("[0] Create a new project\n");
    printf("[1] Load existing project\n");
}


/**
 * @brief Displays the main program menu.
 *
 * Shows all available actions that can be performed on the movie project.
 */
void printMainMenu()
{
    printf("What would you like to do?\n");
    printf("[0] Exit\n");
    printf("[1] Add new Frame\n");
    printf("[2] Remove a Frame\n");
    printf("[3] Change frame index\n");
    printf("[4] Change frame duration\n");
    printf("[5] Change duration of all frames\n");
    printf("[6] List frames\n");
    printf("[7] Play movie!\n");
    printf("[8] Save project\n");
}

/**
 * @brief Gets the user's menu choice.
 *
 * Reads an integer from standard input and clears any remaining
 * characters from the input buffer.
 *
 * @return The user's selected menu option.
 */
int getChoice()
{
    int choice = -1;
    scanf("%d", &choice);

    int c;
    while ((c = getchar()) != '\n');
    
    return choice;
}

/**
 * @brief Reads a string from standard input.
 *
 * Allocates memory for the string, reads a line from the user,
 * and removes the trailing newline character if present.
 *
 * @return Pointer to the allocated string, or NULL if allocation fails.
 *
 * @note The caller is responsible for freeing the returned string.
 */
char *getString()
{
    char *string = (char *)malloc(MAX_SIZE);
    if (!string)
    {   
        return NULL;
    }
    fgets(string, MAX_SIZE, stdin);

    string[strcspn(string, "\n")] = '\0';

    return string;
}

/**
 * @brief Reads a frame duration from standard input.
 *
 * Reads an integer value representing a duration in milliseconds
 * and clears any remaining characters from the input buffer.
 *
 * @return The entered duration in milliseconds.
 */
unsigned int getDuration()
{
    int duration = 0;
    scanf("%d", &duration);

    int c;
    while ((c = getchar()) != '\n');

    return duration;
}