#ifndef LINKEDLISTH
#define LINKEDLISTH

#include <stdbool.h>

typedef struct Frame
{
    char *name;
    unsigned int duration;
    char *path;
} Frame;

typedef struct FrameNode
{
    Frame *frame;
    struct FrameNode *next;
} FrameNode;

Frame *buildFrame(char *name, unsigned int duration, char *path);
FrameNode *createNode(Frame *data);
FrameNode *findLast(FrameNode *head);
void attachNode(FrameNode **head, FrameNode **last, FrameNode *newNode);
FrameNode *searchNode(FrameNode *head, const char *name);
bool removeFrame(FrameNode **head, FrameNode **last, const char *name);
bool editOneDuration(FrameNode *head, const char *name, int duration);
void editAllDuration(FrameNode *head, int newDuration);
void switchFrames(FrameNode *firstFrame, FrameNode *secondFrame);
void listFrames(FrameNode *head);
void freeNode(FrameNode *node);
void freeList(FrameNode *head);

#endif