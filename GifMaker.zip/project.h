#ifndef PROJECTH
#define PROJECTH

#include "Linkedlist.h"
#include <stdio.h>

FrameNode *loadProject(const char *filePath);
bool saveProject(const char *filePath, FrameNode *head);

#endif