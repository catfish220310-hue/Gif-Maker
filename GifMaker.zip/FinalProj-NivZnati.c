#include "Linkedlist.h"
#include "interaction.h"
#include "view.h"
#include "Project.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


int main()
{
    FrameNode *head = NULL;
    FrameNode *last = NULL;
    char *name = NULL;
    char *path = NULL;
    int duration = 0;
    int choice = -1;


    do {
        displayStartupMenu();
        choice = getChoice();
        
        switch (choice)
        {
            case 0:
                printf("Working on a new project.\n");
                break;
            case 1:
            {
                path = getString();
                head = loadProject(path);
                last = findLast(head);
            }
            default:
                break;
        }
    } while (!(choice == 1 || choice == 0));


    do {
        printMainMenu();
        choice = getChoice();

        switch (choice)
        {
            case 0:
            {
                break;
            }
            case 1:
            {
                printf("*** Creating new frame ***\n");
                printf("Please insert frame path: \n");
                path = getString(); 
                printf("Please insert frame duration(in miliseconds):\n");
                duration = getDuration(); 
                printf("Please choose a name for that frame:\n");
                name = getString(); 
                if (searchNode(head, name))
                {
                    printf("Name exists already!\n");
                    free(name);
                    free(path);
                    break;
                }
                
                FILE *f = fopen(path, "r");
                if (!f)
                { 
                    printf("Can't find file! Frame will not be added\n");
                    free(name);
                    free(path);
                    break;
                }   
                fclose(f);

                Frame *newFrame = buildFrame(name, duration, path); 
                FrameNode *newNode = createNode(newFrame); 
                attachNode(&head, &last, newNode); 
                break;
            }
            case 2:
            {
                name = getString();
                bool flag = removeFrame(&head, &last, name);
                if (!flag)
                {
                    printf("The frame was not found\n");   
                }
                free(name);
                break;
            }
            case 3:
            {
                printf("Enter the name of the frame: ");
                name = getString();
                FrameNode *node1 = searchNode(head, name);
                
                if (!node1)
                {
                    printf("couldnt find the node\n");
                    free(name);
                    break;
                }

                free(name);

                printf("Enter the new index in the movie you wish to place the frame\n");
                name = getString();
                FrameNode *node2 = searchNode(head, name);
                if (!node2)
                {
                    printf("couldnt find the node\n");
                    free(name);
                    break;
                }
                
                switchFrames(node1, node2);
                free(name);
                break;
            }
            case 4:
            {
                printf("Enter the name of the frame: \n");
                name = getString();
                printf("Enter the new duration\n");
                duration = getDuration();
                editOneDuration(head, name, duration);
                free(name);
                break;
            }
            case 5:
            {
                printf("Enter the duration for all frames:");
                duration = getDuration();          
                editAllDuration(head, duration);
                break;
            }
            case 6:
            {
                listFrames(head);
                break;
            }
            case 7:
            {
                play(head);
                break;
            }
            case 8:
            {
                printf("Where to save the project? enter a full path and file name\n");
                path = getString();
                bool flag = saveProject(path, head);
                if (!flag)
                {
                    printf("Failed to save project\n");
                }
                free(path);
                break;
            }
            default:
                printf("Illegal input! Enter again.");
                break;
        }
    } while (choice);

    freeList(head);
    head = NULL;
    last = NULL;
    name = NULL;
    path = NULL;

    return 0;
}