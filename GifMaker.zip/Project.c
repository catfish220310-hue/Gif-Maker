#include "project.h"
#include "Linkedlist.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_SIZE 4096


/**
 * @brief Loads a project from a file.
 *
 * Reads frame information from the specified file and constructs
 * a linked list of frames. Each line in the file is expected to be
 * in the following format:
 *
 * path,duration,name
 *
 * @param filePath Path to the project file.
 * @return Pointer to the head of the loaded frame list,
 *         or NULL if the file could not be opened.
 */
FrameNode *loadProject(const char *filePath)
{
    FILE *file = fopen(filePath, "r");
    if (!file)
    {
        return NULL;
    }

    char buffer[MAX_SIZE] = {0};
    FrameNode *head = NULL;
    FrameNode *last = NULL;
    int duration = 0;

    int ch;
    while (fgets(buffer, MAX_SIZE, file))
    {
        buffer[strcspn(buffer, "\n")] = '\0';
        char *comma1 = strchr(buffer, ',');
        if (!comma1) 
        {
            continue;;
        }
        *comma1 = '\0';

        char *comma2 = strchr(comma1 + 1, ',');
        if (!comma2) 
        {   
            continue;;
        }
        *comma2 = '\0';

        char *path = malloc(strlen(buffer) + 1);
        if (!path) 
        {
            continue;
        }
        strcpy(path, buffer);

        char *name = malloc(strlen(comma2 + 1) + 1);
        if (!name)
        {
            free(path);
            continue;
        }
        strcpy(name, comma2 + 1);

        duration = atoi(comma1 + 1);


        Frame *frame = buildFrame(name, duration, path);
        FrameNode *node = createNode(frame);
        attachNode(&head, &last, node);
    }
    fclose(file);
    return head;
}


/**
 * @brief Saves a project to a file.
 *
 * Writes all frames in the linked list to the specified file.
 * Each frame is saved in the following format:
 *
 * path,duration,name
 *
 * One frame is written per line.
 *
 * @param filePath Path to the output project file.
 * @param head Pointer to the head of the frame list.
 * @return true if the project was saved successfully,
 *         false if the file could not be opened.
 */
bool saveProject(const char *filePath, FrameNode *head)
    {
    FILE *file = fopen(filePath, "w");
    if (!file)
    {
        return false;
    }

    while(head)
    {
        fprintf(file, "%s,%u,%s\n", head->frame->path, head->frame->duration, head->frame->name);
        head = head->next;
    }

    fclose(file);
    return true;
}