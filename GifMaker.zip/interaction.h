#ifndef INTERACTIONH
#define INTERACTIONH

//input functions
int getChoice();
char *getString();
unsigned int getDuration();

//output functions
void displayStartupMenu();
void printMainMenu();

#endif 